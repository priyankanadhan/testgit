<?php

use Phalcon\Mvc\Micro;
use Phalcon\Validation;
use Phalcon\Validation\Validator\Email;
use Phalcon\Validation\Validator\Alpha;
use Phalcon\Validation\Validator\Digit;
use Phalcon\Validation\Validator\StringLength;
use Phalcon\Validation\Validator\PresenceOf;
class UsersController extends \Phalcon\Mvc\Controller {
    public function index() {

    }
    /**
     * Fetch all Record from database :-
     */
    public function viewall() {
        $parentsprofile_view = Users::find();
        if ($parentsprofile_view):
            return Json_encode($parentsprofile_view);
        else:
            return $this->response->setJsonContent(['status' => false, 'Message' => 'Failed']);
        endif;
    }

    /*
     * Fetch Record from database based on ID :-
     */

    public function getbyid() {
        $input_data = $this->request->getJsonRawBody();
        $id = isset($input_data->id) ? $input_data->id : '';
        if (empty($id)):
            return $this->response->setJsonContent(['status' => false, 'message' => 'Invalid input parameter']);
        else:
            $parentsprofile_getbyid = Users::findFirstByid($id);
            if ($parentsprofile_getbyid):
                return Json_encode($parentsprofile_getbyid);
            else:
                return $this->response->setJsonContent(['status' => false, 'Message' => 'Data not found']);
            endif;
        endif;
    }

    /**
     * This function using to create NidaraParentsProfile information
     */
    public function create() {

        $input_data = $this->request->getJsonRawBody();

        /**
         * This object using valitaion
         */
        $validation = new Validation();
        $validation->add('parent_type', new PresenceOf(['message' => 'Parent type is required']));
        $validation->add('first_name', new PresenceOf(['message' => 'First name is required']));
        $validation->add('first_name', new Alpha(['message'=>'First Name is only letters']));
        $validation->add('first_name', new StringLength(['max'=>20,'min'=> 2,'messageMaximum' => 'First name is maximum 20',
            'messageMinimum' => 'First Name is minimum 2']));
        $validation->add('last_name', new PresenceOf(['message' => 'Last name is required']));
        $validation->add('last_name', new Alpha(['message'=>'Last Name is only letters']));
        $validation->add('last_name', new StringLength(['max'=>20,'min'=> 2,'messageMaximum' => 'Last name is maximum 20',
            'messageMinimum' => 'Last Name is minimum 2']));
        $validation->add('email', new PresenceOf(['message' => 'Email is required']));
        $validation->add('email', new Email(['message' => 'The e-mail is not valid']));
        $validation->add('mobile', new PresenceOf(['message' => 'Mobile Number is required']));
        $validation->add('mobile', new Digit(['message'=>'Mobile number only digit']));
        $validation->add('occupation', new PresenceOf(['message' => 'Occupation is required']));
        $validation->add('company_name', new PresenceOf(['message' => 'Company name is required']));
        $messages = $validation->validate($input_data);
        if (count($messages)):
            foreach ($messages as $message) :
                $result[] = $message->getMessage();
            endforeach;
            return $this->response->setJsonContent($result);
        else:
            $parentsprofile_create = new Users();
            $parentsprofile_create->id = $this->parentsidgen->getNewId("nidaraparents");
            $parentsprofile_create->parent_type = $input_data->parent_type;
	    $parentsprofile_create->user_type = 'parent';
            $parentsprofile_create->first_name = $input_data->first_name;
            $parentsprofile_create->last_name = $input_data->last_name;
            $parentsprofile_create->email = $input_data->email;
            $parentsprofile_create->mobile = $input_data->mobile;
            $parentsprofile_create->occupation = $input_data->occupation;
            $parentsprofile_create->company_name = $input_data->company_name;
            $parentsprofile_create->created_at = date('Y-m-d H:i:s');
            $parentsprofile_create->created_by = 1;
            $parentsprofile_create->modified_at = date('Y-m-d H:i:s');
            if ($parentsprofile_create->save()):
                return $this->response->setJsonContent(['status' => true, 'message' => 'succefully']);
            else:
                return $this->response->setJsonContent(['status' => false, 'message' => 'Failed']);
            endif;
        endif;
    }

    /**
     * This function using to NidaraParentsProfile information edit
     */
    public function update() {

        $input_data = $this->request->getJsonRawBody();
        $id = isset($input_data->id) ? $input_data->id : '';
        if (empty($id)):
            return $this->response->setJsonContent(['status' => false, 'message' => 'Id is null']);
        else:
            $validation = new Validation();
            $validation->add('parent_type', new PresenceOf(['message' => 'Parent type is required']));
            $validation->add('first_name', new PresenceOf(['message' => 'First Name is required']));
            $validation->add('last_name', new PresenceOf(['message' => 'Last Name is required']));
            $validation->add('email', new PresenceOf(['message' => 'Email is required']));
            $validation->add('mobile', new PresenceOf(['message' => 'Mobile Number is required']));
            $validation->add('occupation', new PresenceOf(['message' => 'Occupation is required']));
            $validation->add('company_name', new PresenceOf(['message' => 'Company Name is required']));
            $messages = $validation->validate($input_data);
            if (count($messages)):
                foreach ($messages as $message):
                    $result[] = $message->getMessage();
                endforeach;
                return $this->response->setJsonContent($result);
            else:
                $parentsprofile_update = Users::findFirstByid($id);
                if ($parentsprofile_update):
                    $parentsprofile_update->id = $input_data->id;
                    $parentsprofile_update->parent_type = $input_data->parent_type;
                    $parentsprofile_update->first_name = $input_data->first_name;
                    $parentsprofile_update->last_name = $input_data->last_name;
                    $parentsprofile_update->email = $input_data->email;
                    $parentsprofile_update->mobile = $input_data->mobile;
                    $parentsprofile_update->occupation = $input_data->occupation;
                    $parentsprofile_update->company_name = $input_data->company_name;
                    $parentsprofile_update->created_by = $id;
                    $parentsprofile_update->modified_at =date('Y-m-d H:i:s');
                    if ($parentsprofile_update->save()):
                        return $this->response->setJsonContent(['status' => true, 'message' => 'succefully']);
                    else:
                        return $this->response->setJsonContent(['status' => false, 'message' => 'Failed']);
                    endif;
                else:
                    return $this->response->setJsonContent(['status' => false, 'message' => 'Invalid id']);
                endif;
            endif;
        endif;
    }

    /**
     * This function using delete kids caregiver information
     */
    public function delete() {

        $input_data = $this->request->getJsonRawBody();
        $id = isset($input_data->id) ? $input_data->id : '';
        if (empty($id)):
            return $this->response->setJsonContent(['status' => false, 'message' => 'Id is null']);
        else:
            $parentsprofile_delete = Users::findFirstByid($id);
            if ($parentsprofile_delete):
                if ($parentsprofile_delete->delete()):
                    return $this->response->setJsonContent(['status' => true, 'Message' => 'Record has been deleted succefully ']);
                else:
                    return $this->response->setJsonContent(['status' => false, 'Message' => 'Data could not be deleted']);
                endif;
            else:
                return $this->response->setJsonContent(['status' => false, 'Message' => 'ID doesn\'t']);
            endif;
        endif;
    }

}
