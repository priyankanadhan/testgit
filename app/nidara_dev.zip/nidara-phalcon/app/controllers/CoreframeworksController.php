<?php
use Phalcon\Mvc\Micro;
use Phalcon\Validation;
use Phalcon\Validation\Validator\PresenceOf;
class CoreframeworksController extends \Phalcon\Mvc\Controller {
	public function index() {
	}
	/**
	 * Fetch all Record from database :-
	 */
	public function viewall() {
		$core_frm = CoreFrameworks::find ();
		if ($core_frm) :
			return Json_encode ( $core_frm );
		 else :
			return $this->response->setJsonContent ( [ 
					'status' => false,
					'Message' => 'Faield' 
			] );
		endif;
	}
	/*
	 * Fetch Record from database based on ID :-
	 */
	public function getbyid() {
		$input_data = $this->request->getJsonRawBody ();
		$id = isset ( $input_data->id ) ? $input_data->id : '';
		if (empty ( $id )) :
			return $this->response->setJsonContent ( [ 
					'status' => false,
					'message' => 'Invalid input parameter' 
			] );
		 else :
			$core_frm_getbyid = CoreFrameworks::findFirstByid ( $id );
			if ($core_frm_getbyid) :
				return Json_encode ( $core_frm_getbyid );
			 else :
				return $this->response->setJsonContent ( [ 
						'status' => false,
						'Message' => 'Data not found' 
				] );
			endif;
		endif;
	}
	/**
	 * This function using to create CoreFrameworks information
	 */
	public function create() {
		$input_data = $this->request->getJsonRawBody ();
		
		/**
		 * This object using valitaion
		 */
		$validation = new Validation ();
		$validation->add ( 'name', new PresenceOf ( [ 
				'message' => 'name is required' 
		] ) );
		$validation->add ( 'status', new PresenceOf ( [ 
				'message' => 'status is required' 
		] ) );
		$messages = $validation->validate ( $input_data );
		if (count ( $messages )) :
			foreach ( $messages as $message ) :
				$result [] = $message->getMessage ();
			endforeach
			;
			return $this->response->setJsonContent ( $result );
		 else :
			$core_frm_create = new CoreFrameworks ();
			$core_frm_create->id = $input_data->id;
			$core_frm_create->name = $input_data->name;
			$core_frm_create->status = $input_data->status;
			$core_frm_create->created_at = date ( 'Y-m-d H:i:s' );
			$core_frm_create->created_by = 1;
			if ($core_frm_create->save ()) :
				return $this->response->setJsonContent ( [ 
						'status' => true,
						'message' => 'successfully' 
				] );
			 else :
				return $this->response->setJsonContent ( [ 
						'status' => false,
						'message' => 'Failed' 
				] );
			endif;
		endif;
	}
	/**
	 * This function using to CoreFrameworks information edit
	 */
	public function update() {
		$input_data = $this->request->getJsonRawBody ();
		$id = isset ( $input_data->id ) ? $input_data->id : '';
		if (empty ( $id )) :
			return $this->response->setJsonContent ( [ 
					'status' => false,
					'message' => 'Id is null' 
			] );
		 else :
			$validation = new Validation ();
			$validation->add ( 'name', new PresenceOf ( [ 
					'message' => 'name is required' 
			] ) );
			$validation->add ( 'status', new PresenceOf ( [ 
					'message' => 'status is required' 
			] ) );
			$messages = $validation->validate ( $input_data );
			if (count ( $messages )) :
				foreach ( $messages as $message ) :
					$result [] = $message->getMessage ();
				endforeach
				;
				return $this->response->setJsonContent ( $result );
			 else :
				$core_frm_update = CoreFrameworks::findFirstByid ( $id );
				if ($core_frm_update) :
					$core_frm_update->name = $input_data->name;
					$core_frm_update->status = $input_data->status;
					$core_frm_update->created_by = $id;
					if ($core_frm_update->save ()) :
						return $this->response->setJsonContent ( [ 
								'status' => true,
								'message' => 'successfully' 
						] );
					 else :
						return $this->response->setJsonContent ( [ 
								'status' => false,
								'message' => 'Failed' 
						] );
					endif;
				 else :
					return $this->response->setJsonContent ( [ 
							'status' => false,
							'message' => 'Invalid id' 
					] );
				endif;
			endif;
		endif;
	}
	/**
	 * This function using delete kids caregiver information
	 */
	public function delete() {
		$input_data = $this->request->getJsonRawBody ();
		$id = isset ( $input_data->id ) ? $input_data->id : '';
		if (empty ( $id )) :
			return $this->response->setJsonContent ( [ 
					'status' => false,
					'message' => 'Id is null' 
			] );
		 else :
			$core_frm_delete = CoreFrameworks::findFirstByid ( $id );
			if ($core_frm_delete) :
				if ($core_frm_delete->delete ()) :
					return $this->response->setJsonContent ( [ 
							'status' => true,
							'Message' => 'Record has been deleted successfully ' 
					] );
				 else :
					return $this->response->setJsonContent ( [ 
							'status' => false,
							'Message' => 'Data could not be deleted' 
					] );
				endif;
			 else :
				return $this->response->setJsonContent ( [ 
						'status' => false,
						'Message' => 'ID doesn\'t' 
				] );
			endif;
		endif;
	}
	
	/**
	 * Get core frameworks details
	 * @return array
	 */
	public function getcoreframeworks() {
		$input_data = $this->request->getJsonRawBody ();
		$id = isset ( $input_data->kid_id ) ? $input_data->kid_id : '';
		/*$core_frm = $this->modelsManager->createBuilder ()->columns ( array (
				'GuidedLearningSchedule.id as guided_id',
				'GamesDatabase.id',
				'GamesDatabase.game_id',
				'GamesDatabase.games_name',
				'GamesDatabase.games_folder',
				'GamesDatabase.status'
		) )->from ( 'KidGuidedLearningMap' )
		->join ( 'GuidedLearning', 'KidGuidedLearningMap.guided_learning_id=GuidedLearning.id' )
		->join ( 'GuidedLearningSchedule', 'GuidedLearningSchedule.guided_learning_id=GuidedLearning.id' )
		->join ( 'GuidedLearningGamesMap', 'GuidedLearningGamesMap.guided_learning_schedule_id=GuidedLearningSchedule.id' )
		->join ( 'GamesTagging', 'GamesTagging.id=GuidedLearningGamesMap.games_tagging_id' )
		->join ( 'GamesDatabase', 'GamesTagging.games_database_id=GamesDatabase.id' )
		->join ( 'Indicators', 'GamesTagging.indicators_id=Indicators.id' )
		->join ( 'StandardIndicatorsMap', 'StandardIndicatorsMap.indicators_id=Indicators.id' )
		->join ( 'Standard', 'GamesTagging.indicators_id=Indicators.id' )
		->join ( 'StandardSubject', 'Standard.id=StandardSubject.standard_id' )
		->join ( 'Subject', 'Subject.id=StandardSubject.subject_id' )
		->join ( 'CoreFrameworksSubjectMap', 'Subject.id=CoreFrameworksSubjectMap.subject_id' )
		->join ( 'CoreFrameworks', 'CoreFrameworks.id=CoreFrameworksSubjectMap.core_framework_id' )
		->groupBy ("GamesDatabase.id")
		->where ( "KidGuidedLearningMap.nidara_kid_profile_id", array (
				$id
		) )->getQuery ()->execute ();
		foreach ( $core_frm as $core_data ) {
			$core_frm_array [] = $core_data;
		}
		return Json_encode ( $core_frm_array );*/
		
		
		
		$core_frm = CoreFrameworks::find ();
		foreach ( $core_frm as $core_data ) {
			$coreid = $core_data->id;
			$core_frm_subject = CoreFrameworksSubjectMap::find ( "core_framework_id=$coreid" );
			$subjects = array ();
			foreach ( $core_frm_subject as $data ) {
				$core_map_id = $data->subject_id;
				$subject = Subject::find ( "id=$core_map_id" )->toArray ();
				$subjects [] = $subject;
			}
			$core_frm_array [$core_data->name] = $subjects;
		}
		if ($core_frm_array) :
			return Json_encode ( $core_frm_array );
 			endif;
	}
}
