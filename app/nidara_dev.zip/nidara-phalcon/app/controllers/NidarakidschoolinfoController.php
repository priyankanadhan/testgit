<?php

use Phalcon\Mvc\Micro;
use Phalcon\Validation;
use Phalcon\Validation\Validator\Digit;
use Phalcon\Validation\Validator\Alpha;
use Phalcon\Validation\Validator\Date;
use Phalcon\Validation\Validator\PresenceOf;

class NidarakidschoolinfoController extends \Phalcon\Mvc\Controller {

    public function index() {

    }

    /**
     * Fetch all Record from database :-
     */
    public function viewall() {
        $kidschoolinfo_view = NidaraKidSchoolInfo::find();
        if ($kidschoolinfo_view):
            return Json_encode($kidschoolinfo_view);
        else:
            return $this->response->setJsonContent(['status' => false, 'Message' => 'Faield']);
        endif;
    }

    /*
     * Fetch Record from database based on ID :-
     */

    public function getbyid() {

        $input_data = $this->request->getJsonRawBody();
        $id = isset($input_data->id) ? $input_data->id : '';
        if (empty($id)):
            return $this->response->setJsonContent(['status' => false, 'message' => 'Invalid input parameter']);
        else:
            $kidschoolinfo_getbyid = NidaraKidSchoolInfo::findFirstByid($id);
            if ($kidschoolinfo_getbyid):
                return Json_encode($kidschoolinfo_getbyid);
            else:
                return $this->response->setJsonContent(['status' => false, 'Message' => 'Data not found']);
            endif;
        endif;
    }

    /**
     * This function using to create NidaraKidSchoolInfo information
     */
    public function create() {

        $input_data = $this->request->getJsonRawBody();

        /**
         * This object using valitaion
         */
        $validation = new Validation();
        $validation->add('nidara_kid_profile_id',new PresenceOf(['message' => 'Nidara kid profile id is required']));
        $validation->add('school_name', new PresenceOf(['message' => 'School name is required']));
        $validation->add('school_name', new Alpha(['message'=>'School Name must contain only letters']));
        $validation->add('school_type', new PresenceOf(['message' => 'School type is required']));
        $validation->add('address2', new PresenceOf(['message' => 'Address 2 is required']));
        $validation->add('town_city', new PresenceOf(['message' => 'Town city is required']));
        $validation->add('state', new PresenceOf(['message' => 'State is required']));
        $validation->add('country', new PresenceOf(['message' => 'Country is required']));
        $messages = $validation->validate($input_data);
        if (count($messages)):
            foreach ($messages as $message) :
                $result[] = $message->getMessage();
            endforeach;
            return $this->response->setJsonContent($result);
        else:
            $kidschoolinfo_create = new NidaraKidSchoolInfo();
            $kidschoolinfo_create->id = $this->kididgen->getNewId("nidarakidschoolinfo");
            $kidschoolinfo_create->nidara_kid_profile_id = $input_data->nidara_kid_profile_id;
            $kidschoolinfo_create->school_name = $input_data->school_name;
            $kidschoolinfo_create->school_type = $input_data->school_type;
            $kidschoolinfo_create->address2 = $input_data->address2;
            $kidschoolinfo_create->town_city = $input_data->town_city;
            $kidschoolinfo_create->state = $input_data->state;
            $kidschoolinfo_create->country = $input_data->country;
            $kidschoolinfo_create->created_at =date('Y-m-d H:i:s');
            $kidschoolinfo_create->created_by = 1;
            $kidschoolinfo_create->modified_at = date('Y-m-d H:i:s');
            if ($kidschoolinfo_create->save()):
                return $this->response->setJsonContent(['status' => true, 'message' => 'succefully']);
            else:
                return $this->response->setJsonContent(['status' => false, 'message' => 'Failed']);
            endif;
        endif;
    }

    /**
     * This function using to NidaraKidSchoolInfo information edit
     */
    public function update() {

        $input_data = $this->request->getJsonRawBody();
        $id = isset($input_data->id) ? $input_data->id : '';
        if (empty($id)):
            return $this->response->setJsonContent(['status' => false, 'message' => 'Id is null']);
        else:
            $validation = new Validation();
            $validation->add('nidara_kid_profile_id', new PresenceOf(['message' => 'Nidara kid profile id is required']));
            $validation->add('school_name', new PresenceOf(['message' => 'School name is required']));
            $validation->add('school_name', new Alpha(['message'=>'School Name must contain only letters']));
            $validation->add('school_type', new PresenceOf(['message' => 'School type is required']));
            $validation->add('address2', new PresenceOf(['message' => 'Address 2 is required']));
            $validation->add('town_city', new PresenceOf(['message' => 'Town city is required']));
            $validation->add('state', new PresenceOf(['message' => 'State is required']));
            $validation->add('country', new PresenceOf(['message' => 'Country is required']));
            $messages = $validation->validate($input_data);
            if (count($messages)):
                foreach ($messages as $message):
                    $result[] = $message->getMessage();
                endforeach;
                return $this->response->setJsonContent($result);
            else:
                $kidschoolinfo_update = NidaraKidSchoolInfo::findFirstByid($id);
                if ($kidschoolinfo_update):
                    $kidschoolinfo_update->id = $input_data->id;
                    $kidschoolinfo_update->nidara_kid_profile_id = $input_data->nidara_kid_profile_id;
                    $kidschoolinfo_update->school_name = $input_data->school_name;
                    $kidschoolinfo_update->school_type = $input_data->school_type;
                    $kidschoolinfo_update->address2 = $input_data->address2;
                    $kidschoolinfo_update->town_city = $input_data->town_city;
                    $kidschoolinfo_update->state = $input_data->state;
                    $kidschoolinfo_update->country = $input_data->country;
                    $kidschoolinfo_update->created_by =$id;
                    $kidschoolinfo_update->modified_at = date('Y-m-d H:i:s');
                    if ($kidschoolinfo_update->save()):
                        return $this->response->setJsonContent(['status' => true, 'message' => 'succefully']);
                    else:
                        return $this->response->setJsonContent(['status' => false, 'message' => 'Failed']);
                    endif;
                else:
                    return $this->response->setJsonContent(['status' => false, 'message' => 'Invalid id']);
                endif;
            endif;
        endif;
    }

    /**
     * This function using delete kids caregiver information
     */
    public function delete() {

        $input_data = $this->request->getJsonRawBody();
        $id = isset($input_data->id) ? $input_data->id : '';
        if (empty($id)):
            return $this->response->setJsonContent(['status' => false, 'message' => 'Id is null']);
        else:
            $kidschoolinfo_delete = NidaraKidSchoolInfo::findFirstByid($id);
            if ($kidschoolinfo_delete):
                if ($kidschoolinfo_delete->delete()):
                    return $this->response->setJsonContent(['status' => true, 'Message' => 'Record has been deleted succefully ']);
                else:
                    return $this->response->setJsonContent(['status' => false, 'Message' => 'Data could not be deleted']);
                endif;
            else:
                return $this->response->setJsonContent(['status' => false, 'Message' => 'ID doesn\'t']);
            endif;
        endif;
    }

}
