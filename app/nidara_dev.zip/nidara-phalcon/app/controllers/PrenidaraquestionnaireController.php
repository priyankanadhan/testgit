<?php
use Phalcon\Mvc\Micro;
use Phalcon\Validation;
use Phalcon\Validation\Validator\PresenceOf;

class PrenidaraquestionnaireController extends \Phalcon\Mvc\Controller {

    public function index() {

    }

    /**
     * Fetch all Record from database :-
     */
    public function viewall() {
        $answers_view = Answers::find();
        if ($answers_view):
            return Json_encode($answers_view);
        else:
            return $this->response->setJsonContent(['status' => false, 'Message' => 'Failed']);
        endif;
    }

    /*
     * Fetch Record from database based on ID :-
     */

    public function getbyid() {

        $input_data = $this->request->getJsonRawBody();
        $id = isset($input_data->id) ? $input_data->id : '';
        if (empty($id)):
            return $this->response->setJsonContent(['status' => false, 'message' => 'Invalid input parameter']);
        else:
            $answers_getby_id = Answers::findFirstByid($id);
            if ($answers_getby_id):
                return Json_encode($answers_getby_id);
            else:
                return $this->response->setJsonContent(['status' => false, 'Message' => 'Data not found']);
            endif;
        endif;
    }

    /**
     * This function using to create Answers information
     */
    public function create() {

        $input_data = $this->request->getJsonRawBody();
        $question_option=$input_data->questionarie;
        /**
         * This object using valitaion
         */
        $validation = new Validation();
        //$validation->add('questions_id', new PresenceOf(['message' => 'Questions id is required']));
        $validation->add('session_id', new PresenceOf(['message' => 'Session id is required']));
        $validation->add('is_correct', new PresenceOf(['message' => 'Is_correct is required']));
        //$validation->add('options_id', new PresenceOf(['message' => 'options id is required']));
        $validation->add('nidara_kid_profile_id', new PresenceOf(['message' => 'Nidara Kid profile id is required']));
        $messages = $validation->validate($input_data);
        if (count($messages)):

            foreach ($messages as $message) :
                $result[] = $message->getMessage();
            endforeach;

            return $this->response->setJsonContent($result);
        else:
          foreach ($question_option as $key => $value) {
            $answers_create = new Answers();
            $answers_create->id = $this->questionsidgen->getNewId("answers");
            $answers_create->questions_id =$value->questions_id;
            $answers_create->session_id = $input_data->session_id;
            $answers_create->is_correct = $input_data->is_correct;
            $answers_create->options_id = $value->options_id;
            $answers_create->nidara_kid_profile_id = $input_data->nidara_kid_profile_id;
            $answers_create->created_at =date('Y-m-d H:i:s');
            $answers_create->created_by = 1;
            $answers_create->modified_at =date('Y-m-d H:i:s');
            if (!$answers_create->save()){
                return $this->response->setJsonContent(['status' => false, 'message' => 'Failed']);
            }
          }
          return $this->response->setJsonContent(['status' => true, 'message' => 'successfully']);

        endif;

    }

    /**
     * This function using to Answers information edit
     */
    public function update() {

        $input_data = $this->request->getJsonRawBody();
        $id = isset($input_data->id) ? $input_data->id : '';
        if (empty($id)):
            return $this->response->setJsonContent(['status' => false, 'message' => 'Id is null']);
        else:
            $validation = new Validation();
            $validation->add('questions_id', new PresenceOf(['message' => 'Questions id is required']));
            $validation->add('session_id', new PresenceOf(['message' => 'Session id is required']));
            $validation->add('is_correct', new PresenceOf(['message' => 'Is_correct is required']));
            $validation->add('options_id', new PresenceOf(['message' => 'options id is required']));
            $validation->add('nidara_kid_profile_id', new PresenceOf(['message' => 'Nidara kid profile id is required']));
            $messages = $validation->validate($input_data);
            if (count($messages)):
                foreach ($messages as $message):
                    $result[] = $message->getMessage();
                endforeach;
                return $this->response->setJsonContent($result);
            else:
                $answers_update = Answers::findFirstByid($id);
                if ($answers_update):
                    $answers_update->questions_id = $input_data->questions_id;
                    $answers_update->session_id = $input_data->session_id;
                    $answers_update->is_correct = $input_data->is_correct;
                    $answers_update->options_id = $input_data->options_id;
                    $answers_update->nidara_kid_profile_id = $input_data->nidara_kid_profile_id;
                    $answers_update->created_by = $id;
                    $answers_update->modified_at = date('Y-m-d H:i:s');
                    if ($answers_update->save()):
                        return $this->response->setJsonContent(['status' => true, 'message' => 'succefully']);
                    else:
                        return $this->response->setJsonContent(['status' => false, 'message' => 'Failed']);
                    endif;
                else:
                    return $this->response->setJsonContent(['status' => false, 'message' => 'Invalid id']);
                endif;
            endif;
        endif;
    }

    /**
     * This function using delete kids caregiver information
     */
    public function delete() {

        $input_data = $this->request->getJsonRawBody();
        $id = isset($input_data->id) ? $input_data->id : '';
        if (empty($id)):
            return $this->response->setJsonContent(['status' => false, 'message' => 'Id is null']);
        else:
            $answers_delete = Answers::findFirstByid($id);
            if ($answers_delete):
                if ($answers_delete->delete()):
                    return $this->response->setJsonContent(['status' => true, 'Message' => 'Record has been deleted succefully ']);
                else:
                    return $this->response->setJsonContent(['status' => false, 'Message' => 'Data could not be deleted']);
                endif;
            else:
                return $this->response->setJsonContent(['status' => false, 'Message' => 'ID doesn\'t']);
            endif;
        endif;
    }

}
