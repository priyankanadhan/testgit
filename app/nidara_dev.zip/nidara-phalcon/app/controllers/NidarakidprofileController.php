<?php
use Phalcon\Mvc\Micro;
use Phalcon\Validation;
use Phalcon\Validation\Validator\Digit;
use Phalcon\Validation\Validator\Alpha;
use Phalcon\Validation\Validator\Date;
use Phalcon\Validation\Validator\StringLength;
use Phalcon\Validation\Validator\PresenceOf;

class NidarakidprofileController extends \Phalcon\Mvc\Controller {

    public function index() {

    }

    /**
     * Fetch all Record from database :-
     */
    public function viewall() {
        $kidprofile_view = NidaraKidProfile::find();
        if ($kidprofile_view):
            return Json_encode($kidprofile_view);
        else:
            return $this->response->setJsonContent(['status' =>false, 'Message' => 'Failed']);
        endif;
    }

    /*
     * Fetch Record from database based on ID :-
     */

    public function getbyid() {

        $input_data = $this->request->getJsonRawBody();
        $id = isset($input_data->id) ? $input_data->id : '';
        if (empty($id)):
            return $this->response->setJsonContent(['status' => false, 'message' => 'Invalid input parameter']);
        else:
            $kidprofile_getbyid = NidaraKidProfile::findFirstByid($id);
            if ($kidprofile_getbyid):
                return Json_encode($kidprofile_getbyid);
            else:
                return $this->response->setJsonContent(['status' => false, 'Message' => 'Data not found']);
            endif;
        endif;
    }

    /**
     * This function using to create NidaraKidProfile information
     */
    public function create() {

        $input_data = $this->request->getJsonRawBody();
	if(empty($input_data)){
		return $this->response->setJsonContent(["status"=>false,"message"=>"Please give the input datas"]);
	}
        /**
         * This object using valitaion
         */
        $validation = new Validation();
        $validation->add('first_name', new PresenceOf(['message' => 'Frirst Name is required']));
        $validation->add('first_name', new Alpha(['message'=>'Field must contain only letters']));
        $validation->add('first_name', new StringLength(['max'=>20,'min'=> 2,'messageMaximum' => 'Frirst Name is maximum 20',
            'messageMinimum' => 'Frirst Name is minimum 2']));
        $validation->add('middle_name', new PresenceOf(['message' => 'Middle Name is required']));
        $validation->add('middle_name', new StringLength(['max'=>20,'min'=> 2,'messageMaximum' => 'Middle Name is maximum 20',
            'messageMinimum' => 'Middle Name is minimum 2']));
        $validation->add('middle_name', new Alpha(['message'=>'Field must contain only letters']));
        $validation->add('last_name', new PresenceOf(['message' => 'Last Name is required']));
        $validation->add('last_name', new Alpha(['message'=>'Field must contain only letters']));
        $validation->add('last_name', new StringLength(['max'=>20,'min'=> 2,'messageMaximum' => 'Last Name is maximum 20',
            'messageMinimum' => 'Last Name is minimum 2']));
        $validation->add('date_of_birth', new PresenceOf(['message' => 'Date of birth is required']));
        $validation->add('date_of_birth',new Date(['format'  => 'Y-m-d','message'=>'The date is invalid']));
        $validation->add('age', new PresenceOf(['message' => 'Age is required']));
        $validation->add('age', new Digit(['message' => 'Age is only digit']));
        $validation->add('gender', new PresenceOf(['message' => 'Gender is required']));
        $validation->add('grade', new PresenceOf(['message' => 'Grade is required']));
        $validation->add('child_photo', new PresenceOf(['message' => 'Child Photo is required']));
        $validation->add('child_avatar', new PresenceOf(['message' => 'Child Avatar is required']));
        $messages = $validation->validate($input_data);
        if (count($messages)):
            foreach ($messages as $message) :
                $result[] = $message->getMessage();
            endforeach;
            return $this->response->setJsonContent($result);
        else:
            $kidprofile_create = new NidaraKidProfile();
            $kidprofile_create->id = $this->kididgen->getNewId("nidarakidprofile");
            $kidprofile_create->first_name = $input_data->first_name;
            $kidprofile_create->middle_name = $input_data->middle_name;
            $kidprofile_create->last_name = $input_data->last_name;
            $kidprofile_create->date_of_birth = $input_data->date_of_birth;
            $kidprofile_create->age = $input_data->age;
            $kidprofile_create->gender = $input_data->gender;
            $kidprofile_create->grade = $input_data->grade;
            $kidprofile_create->child_photo = $input_data->child_photo;
            $kidprofile_create->child_avatar = $input_data->child_avatar;
            $kidprofile_create->created_at = date('Y-m-d H:i:s');
            $kidprofile_create->created_by = 1;
            $kidprofile_create->modified_at = date('Y-m-d H:i:s');
            if ($kidprofile_create->save()):
                return $this->response->setJsonContent(['status' =>true, 'message' => 'succefully']);
            else:
                return $this->response->setJsonContent(['status' => false, 'message' => 'Failed']);
            endif;
        endif;
    }

    /**
     * This function using to NidaraKidProfile information edit
     */
    public function update() {

        $input_data = $this->request->getJsonRawBody();
        $id = isset($input_data->id) ? $input_data->id : '';
        if (empty($id)):
            return $this->response->setJsonContent(['status' =>false, 'message' => 'Id is null']);
        else:
            $validation = new Validation();
            $validation->add('first_name', new PresenceOf(['message' => 'Frirst Name is required']));
            $validation->add('first_name', new Alpha(['message'=>'Field must contain only letters']));
            $validation->add('first_name', new StringLength(['max'=>20,'min'=> 2,'messageMaximum' => 'Frirst Name is maximum 20',
                'messageMinimum' => 'Frirst Name is minimum 2']));
            $validation->add('middle_name', new PresenceOf(['message' => 'Middle Name is required']));
            $validation->add('middle_name', new StringLength(['max'=>20,'min'=> 2,'messageMaximum' => 'Middle Name is maximum 20',
                'messageMinimum' => 'Middle Name is minimum 2']));
            $validation->add('middle_name', new Alpha(['message'=>'Field must contain only letters']));
            $validation->add('last_name', new PresenceOf(['message' => 'Last Name is required']));
            $validation->add('last_name', new Alpha(['message'=>'Field must contain only letters']));
            $validation->add('last_name', new StringLength(['max'=>20,'min'=> 2,'messageMaximum' => 'Last Name is maximum 20',
                'messageMinimum' => 'Last Name is minimum 2']));
            $validation->add('date_of_birth', new PresenceOf(['message' => 'Date of birth is required']));
            $validation->add('date_of_birth',new Date(['format'  => 'Y-m-d','message'=>'The date is invalid']));
            $validation->add('age', new PresenceOf(['message' => 'Age is required']));
            $validation->add('age', new Digit(['message' => 'Age is only digit']));
            $validation->add('gender', new PresenceOf(['message' => 'Gender is required']));
            $validation->add('grade', new PresenceOf(['message' => 'Grade is required']));
            $validation->add('child_photo', new PresenceOf(['message' => 'Child Photo is required']));
            $validation->add('child_avatar', new PresenceOf(['message' => 'Child Avatar is required']));
            $messages = $validation->validate($input_data);
            if (count($messages)):
                foreach ($messages as $message):
                    $result[] = $message->getMessage();
                endforeach;
                return $this->response->setJsonContent($result);
            else:
                $kidprofile_update = NidaraKidProfile::findFirstByid($id);
                if ($kidprofile_update):
                    $kidprofile_update->id = $input_data->id;
                    $kidprofile_update->first_name = $input_data->first_name;
                    $kidprofile_update->middle_name = $input_data->middle_name;
                    $kidprofile_update->last_name = $input_data->last_name;
                    $kidprofile_update->date_of_birth = $input_data->date_of_birth;
                    $kidprofile_update->age = $input_data->age;
                    $kidprofile_update->gender = $input_data->gender;
                    $kidprofile_update->grade = $input_data->grade;
                    $kidprofile_update->child_photo = $input_data->child_photo;
                    $kidprofile_update->child_avatar = $input_data->child_avatar;
                    $kidprofile_update->created_by = $id;
                    $kidprofile_update->modified_at = date('Y-m-d H:i:s');
                    if ($kidprofile_update->save()):
                        return $this->response->setJsonContent(['status' => true, 'message' => 'succefully']);
                    else:
                        return $this->response->setJsonContent(['status' => false, 'message' => 'Failed']);
                    endif;
                else:
                    return $this->response->setJsonContent(['status' => false, 'message' => 'Invalid id']);
                endif;
            endif;
        endif;
    }

    /**
     * This function using delete kids caregiver information
     */
    public function delete() {

        $input_data = $this->request->getJsonRawBody();
        $id = isset($input_data->id) ? $input_data->id : '';
        if (empty($id)):
            return $this->response->setJsonContent(['status' => false, 'message' => 'Id is null']);
        else:
            $kidprofile_delete = NidaraKidProfile::findFirstByid($id);
            if ($kidprofile_delete):
                if ($kidprofile_delete->delete()):
                    return $this->response->setJsonContent(['status' => true, 'Message' => 'Record has been deleted succefully ']);
                else:
                    return $this->response->setJsonContent(['status' => false, 'Message' => 'Data could not be deleted']);
                endif;
            else:
                return $this->response->setJsonContent(['status' => false, 'Message' => 'ID doesn\'t']);
            endif;
        endif;
    }

}
