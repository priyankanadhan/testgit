<?php

use Phalcon\Mvc\Micro;
use Phalcon\Validation;
use Phalcon\Validation\Validator\Digit;
use Phalcon\Validation\Validator\Alpha;
use Phalcon\Validation\Validator\Date;
use Phalcon\Validation\Validator\StringLength;
use Phalcon\Validation\Validator\PresenceOf;

class NidaraparentsaddressinfoController extends \Phalcon\Mvc\Controller {

    public function index() {

    }

    /**
     * Fetch all Record from database :-
     */
    public function viewall() {
        $parentsaddress_view = NidaraParentsAddressInfo::find();
        if ($parentsaddress_view):
            return Json_encode($parentsaddress_view);
        else:
            return $this->response->setJsonContent(['status' => false, 'Message' => 'Failed']);
        endif;
    }

    /*
     * Fetch Record from database based on ID :-
     */

    public function getbyid() {

        $input_data = $this->request->getJsonRawBody();
        $id = isset($input_data->id) ? $input_data->id : '';
        if (empty($id)):
            return $this->response->setJsonContent(['status' => false, 'message' => 'Invalid input parameter']);
        else:
            $parentsaddress_getbyid = NidaraParentsAddressInfo::findFirstByid($id);
            if ($parentsaddress_getbyid):
                return Json_encode($parentsaddress_getbyid);
            else:
                return $this->response->setJsonContent(['status' => false, 'Message' => 'Data not found']);
            endif;
        endif;
    }

    /**
     * This function using to create NidaraParentsAddressInfo information
     */
    public function create() {

        $input_data = $this->request->getJsonRawBody();

        /**
         * This object using valitaion
         */
        $validation = new Validation();
        $validation->add('address_type', new PresenceOf(['message' => 'Address type is required']));
        $validation->add('nidara_parents_profile_id', new PresenceOf(['message' => 'Nidara parents profile id is required']));
        $validation->add('address1', new PresenceOf(['message' => 'Address1 is required']));
        $validation->add('address2', new PresenceOf(['message' => 'Address2 is required']));
        $validation->add('town_city', new PresenceOf(['message' => 'Town city is required']));
        $validation->add('pincode', new PresenceOf(['message' => 'Pincode is required']));
        $validation->add('state', new PresenceOf(['message' => 'State is required']));
        $validation->add('country', new PresenceOf(['message' => 'Country is required']));
        $messages = $validation->validate($input_data);
        if (count($messages)):
            foreach ($messages as $message) :
                $result[] = $message->getMessage();
            endforeach;
            return $this->response->setJsonContent($result);
        else:
            $parentsaddress_create = new NidaraParentsAddressInfo();
            $parentsaddress_create->id = $this->parentsidgen->getNewId("nidaraparentsaddress");
            $parentsaddress_create->address_type = $input_data->address_type;
            $parentsaddress_create->users_id = $input_data->nidara_parents_profile_id;
            $parentsaddress_create->address1 = $input_data->address1;
            $parentsaddress_create->address2 = $input_data->address2;
            $parentsaddress_create->town_city = $input_data->town_city;
            $parentsaddress_create->pincode = $input_data->pincode;
            $parentsaddress_create->state = $input_data->state;
            $parentsaddress_create->country = $input_data->country;
            $parentsaddress_create->created_at = date('Y-m-d H:i:s');
            $parentsaddress_create->created_by = 1;
            $parentsaddress_create->modified_at =date('Y-m-d H:i:s');
            if ($parentsaddress_create->save()):
                return $this->response->setJsonContent(['status' => true, 'message' => 'succefully']);
            else:
                return $this->response->setJsonContent(['status' => false, 'message' => 'Failed']);
            endif;
        endif;
    }

    /**
     * This function using to NidaraParentsAddressInfo information edit
     */
    public function update() {

        $input_data = $this->request->getJsonRawBody();
        $id = isset($input_data->id) ? $input_data->id : '';
        if (empty($id)):
            return $this->response->setJsonContent(['status' => false, 'message' => 'Id is null']);
        else:
            $validation = new Validation();
            $validation->add('address_type', new PresenceOf(['message' => 'Address type is required']));
            $validation->add('nidara_parents_profile_id', new PresenceOf(['message' => 'Nidara parents profile id is required']));
            $validation->add('address1', new PresenceOf(['message' => 'Address1 is required']));
            $validation->add('address2', new PresenceOf(['message' => 'Address2 is required']));
            $validation->add('town_city', new PresenceOf(['message' => 'Town city is required']));
            $validation->add('pincode', new PresenceOf(['message' => 'Pincode is required']));
            $validation->add('state', new PresenceOf(['message' => 'State is required']));
            $validation->add('country', new PresenceOf(['message' => 'Country is required']));
            $messages = $validation->validate($input_data);
            if (count($messages)):
                foreach ($messages as $message):
                    $result[] = $message->getMessage();
                endforeach;
                return $this->response->setJsonContent($result);
            else:
                $parentsaddress_update = NidaraParentsAddressInfo::findFirstByid($id);
                if ($parentsaddress_update):
                    $parentsaddress_update->id = $input_data->id;
                    $parentsaddress_update->address_type = $input_data->address_type;
                    $parentsaddress_update->users_id = $input_data->nidara_parents_profile_id;
                    $parentsaddress_update->address1 = $input_data->address1;
                    $parentsaddress_update->address2 = $input_data->address2;
                    $parentsaddress_update->town_city = $input_data->town_city;
                    $parentsaddress_update->pincode = $input_data->pincode;
                    $parentsaddress_update->state = $input_data->state;
                    $parentsaddress_update->country = $input_data->country;
                    $parentsaddress_update->created_by = $id;
                    $parentsaddress_update->modified_at = date('Y-m-d H:i:s');
                    if ($parentsaddress_update->save()):
                        return $this->response->setJsonContent(['status' => true, 'message' => 'succefully']);
                    else:
                        return $this->response->setJsonContent(['status' => false, 'message' => 'Failed']);
                    endif;
                else:
                    return $this->response->setJsonContent(['status' => false, 'message' => 'Invalid id']);
                endif;
            endif;
        endif;
    }

    /**
     * This function using delete kids caregiver information
     */
    public function delete() {

        $input_data = $this->request->getJsonRawBody();
        $id = isset($input_data->id) ? $input_data->id : '';
        if (empty($id)):
            return $this->response->setJsonContent(['status' => false, 'message' => 'Id is null']);
        else:
            $parentsaddress_delete = NidaraParentsAddressInfo::findFirstByid($id);
            if ($parentsaddress_delete):
                if ($parentsaddress_delete->delete()):
                    return $this->response->setJsonContent(['status' => true, 'Message' => 'Record has been deleted succefully ']);
                else:
                    return $this->response->setJsonContent(['status' => false, 'Message' => 'Data could not be deleted']);
                endif;
            else:
                return $this->response->setJsonContent(['status' => false, 'Message' => 'ID doesn\'t']);
            endif;
        endif;
    }

}
