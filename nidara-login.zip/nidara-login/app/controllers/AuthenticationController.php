<?php
use Phalcon\Mvc\Micro;
use Phalcon\Validation;
use Lcobucci\JWT\Builder;
use Lcobucci\JWT\Signer\Hmac\Sha256;
use Lcobucci\JWT\ValidationData;
use Lcobucci\JWT\Parser;
require BASE_PATH.'/vendor/autoload.php';

class AuthenticationController extends ControllerBase {
	CONST UniqId = '598c2b9752462';
	CONST signer='nidara';
	
	/**
	 * Generate the token
	 */
	public function tokengenerate() {
		$signer = new Sha256();
		$token = (new Builder())->setIssuer($this->config->Issuer) // Configures the issuer (iss claim)
                        ->setAudience($this->config->Audience) // Configures the audience (aud claim)
                        ->setId(self::UniqId, true) // Configures the id (jti claim), replicating as a header item
                        ->setIssuedAt(time()) // Configures the time that the token was issue (iat claim)
                        ->setNotBefore(time() + 60) // Configures the time that the token can be used (nbf claim)
                        ->setExpiration(time() + 3600) // Configures the expiration time of the token (nbf claim)
                        ->set('uid', 1) // Configures a new claim, called "uid"
                        ->sign($signer, self::signer)
                        ->getToken();
		return $token;
	}
	
	/**
	 * Token validation
	 */
	public function validatetoken($token){
		$token = (new Parser())->parse((string) $token);
		$data = new ValidationData (); 
		$data->setIssuer ($this->config->Issuer);
		$data->setAudience ($this->config->Audience );
		$data->setId ( self::UniqId );
		$token->validate ( $data ); // false, because we created a token that cannot be used before of `time() + 60`
		$data->setCurrentTime ( time () + 60 );
		return $token->validate ( $data );
	}

}

