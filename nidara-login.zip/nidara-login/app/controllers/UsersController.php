<?php
                 
use Phalcon\Mvc\Micro;
use Phalcon\Validation;
use Phalcon\Validation\Validator\PresenceOf;
use Phalcon\Validation\Validator\Email;
use Phalcon\Validation\Validator\Digit as DigitValidator;
use Phalcon\Validation\Validator\StringLength as StringLength;
use Phalcon\Validation\Validator\Alpha as AlphaValidator;

                    class UsersController extends \Phalcon\Mvc\Controller {
                        public function index() {        
                        }/**
                        * Fetch all Record from database :-
                        */
                       public function viewall() {
        $users = Users::find();
        if ($users):
            return Json_encode($users);
        else:
            return $this->response->setJsonContent(['status' => false, 'Message' => 'Faield']);
        endif;
    }

    /*
     * Fetch Record from database based on ID :-
     */

    public function getbyid($id = null) {

        $input_data = $this->request->getJsonRawBody();
        $id = isset($input_data->id) ? $input_data->id : '';
        if (empty($id)):
            return $this->response->setJsonContent(['status' => false, 'message' => 'Invalid input parameter']);
        else:
            $users = Users::findFirstByid($id);
            if ($users):
                return Json_encode($users);
            else:
                return $this->response->setJsonContent(['status' => false, 'Message' => 'Data not found']);
            endif;
        endif;
    }

    /**
     * This function using to create NidaraParentsProfile information
     */
    public function create() {

        $input_data = $this->request->getJsonRawBody();

        if (empty($input_data)) {
            return $this->response->setJsonContent(["status" => false, "message" => "Please give the input datas"]);
        }
        /**
         * This object using valitaion 
         */
        $validation = new Validation();
 
        $validation->add('first_name', new PresenceOf(['message' => 'first name is required']));
        $validation->add('last_name', new PresenceOf(['message' => 'last name is required']));
        $validation->add(["first_name", "last_name",], new AlphaValidator(["message" => ["first_name" => "First name must contain only  letters", "last_name " => "Last name must contain only letters",],]));
        $validation->add(["first_name", "last_name",], new StringLength(["max" => ["first_name" => 20, "last_name" => 30,], "min" => [
                "first_name" => 4, "last_name" => 2,],
            "messageMaximum" => ["first_name" => "We don't like really long firstnames", "last_name" => "We don't like really long last names",], "messageMinimum" => ["name_last" => "We don't like too short first names",
                "name_first" => "We don't like too short last names",]]));
        $validation->add('email', new PresenceOf(['message' => 'email is required']));
        $validation->add('email', new Email(['message' => 'The e-mail is not valid',]));
        $validation->add('mobile', new PresenceOf(['message' => 'mobile number is required']));
        $validation->add("mobile", new DigitValidator(["message" => "mobile number field must be numeric",]));
        $validation->add('mobile', new StringLength(["max" => 10, "min" => 10,
            "messageMaximum" => "The Mobile Number must be 10 digits long", "messageMinimum" => "The Mobile Number must be 10 digits long",]));
        $validation->add('occupation', new PresenceOf(['message' => 'occupation is required']));
        $validation->add('company_name', new PresenceOf(['message' => 'company nameis required']));

        $messages = $validation->validate($input_data->mother_info);
        if (count($messages)):
            foreach ($messages as $message):
                $result[] = $message->getMessage();
            endforeach;
            return $this->response->setJsonContent($result);
        else:

            $users_mom = new Users();
            $users_mom->id = $input_data->mother_id;
            $users_mom->parent_type = 'mother';
            $users_mom->user_type ='parent';
            $users_mom->first_name = $input_data->mother_info->first_name;
            $users_mom->last_name = $input_data->mother_info->last_name;
            $users_mom->email = $input_data->mother_info->email;
            $users_mom->mobile = $input_data->mother_info->mobile;
            $users_mom->occupation = $input_data->mother_info->occupation;
            $users_mom->company_name = $input_data->mother_info->company_name;
            $users_mom->created_at = date('Y-m-d H:i:s');
            $users_mom->created_by = $input_data->mother_id;
            $users_mom->modified_at = date('Y-m-d H:i:s');
            $users_mom->country_of_residence = $input_data->mother_info->country_id;
            $users_mom->country_of_citizenship =  $input_data->mother_info->citizen_id;

            $users_mom->save();
        endif;
        $validation = new Validation();
  
        $validation->add('first_name', new PresenceOf(['message' => 'first name is required']));
        $validation->add('last_name', new PresenceOf(['message' => 'last name is required']));
        $validation->add(["first_name", "last_name",], new AlphaValidator(["message" => ["first_name" => "First name must contain only  letters", "last_name " => "Last name must contain only letters",],]));
        $validation->add(["first_name", "last_name",], new StringLength(["max" => ["first_name" => 20, "last_name" => 30,], "min" => [
                "first_name" => 4, "last_name" => 2,],
            "messageMaximum" => ["first_name" => "We don't like really long firstnames", "last_name" => "We don't like really long last names",], "messageMinimum" => ["name_last" => "We don't like too short first names",
                "name_first" => "We don't like too short last names",]]));
        $validation->add('email', new PresenceOf(['message' => 'email is required']));
        $validation->add('email', new Email(['message' => 'The e-mail is not valid',]));
        $validation->add('mobile', new PresenceOf(['message' => 'mobile number is required']));
        $validation->add("mobile", new DigitValidator(["message" => "mobile number field must be numeric",]));
        $validation->add('mobile', new StringLength(["max" => 10, "min" => 10,
            "messageMaximum" => "The Mobile Number must be 10 digits long", "messageMinimum" => "The Mobile Number must be 10 digits long",]));
        $validation->add('occupation', new PresenceOf(['message' => 'occupation is required']));
        $validation->add('company_name', new PresenceOf(['message' => 'company nameis required']));

        $messages = $validation->validate($input_data->father_info);
        if (count($messages)):
            foreach ($messages as $message):
                $result[] = $message->getMessage();
            endforeach;
            return $this->response->setJsonContent($result);
        else:

            $users = new Users();

            $users->id = $input_data->father_id;
            $users->parent_type = 'father';
             $users->user_type ='parent';
            $users->first_name = $input_data->father_info->first_name;
            $users->last_name = $input_data->father_info->last_name;
            $users->email = $input_data->father_info->email;
            $users->mobile = $input_data->father_info->mobile;
            $users->occupation = $input_data->father_info->occupation;
            $users->company_name = $input_data->father_info->company_name;
            $users->created_at = date('Y-m-d H:i:s');
            $users->created_by = $input_data->father_id;
            $users->modified_at = date('Y-m-d H:i:s');
            $users->country_of_residence = $input_data->father_info->country_id;
            $users->country_of_citizenship =  $input_data->father_info->citizen_id;
            //print_r( $parent_profile); exit;
            if ($users->save()):
                return $this->response->setJsonContent(['status' => true, 'message' => 'successfully']);
            else:
                return $this->response->setJsonContent(['status' => false, 'message' => 'Failed']);
            endif;
        endif;
    }

    /**
     * This function using to NidaraParentsProfile information edit
     */
    public function update($id = null) {

        $input_data = $this->request->getJsonRawBody();

        $id = isset($input_data->mother_id) ? $input_data->mother_id : '';
        if (empty($id)):
            return $this->response->setJsonContent(['status' => 'Error', 'message' => 'Id is null']);
        else:
            $validation = new Validation();


            $validation->add('first_name', new PresenceOf(['message' => 'first name is required']));
            $validation->add('last_name', new PresenceOf(['message' => 'last name is required']));
            $validation->add(["first_name", "last_name",], new AlphaValidator(["message" => ["first_name" => "First name must contain only  letters", "last_name " => "Last name must contain only letters",],]));
            $validation->add(["first_name", "last_name",], new StringLength(["max" => ["first_name" => 20, "last_name" => 30,], "min" => [
                    "first_name" => 4, "last_name" => 2,],
                "messageMaximum" => ["first_name" => "We don't like really long firstnames", "last_name" => "We don't like really long last names",], "messageMinimum" => ["name_last" => "We don't like too short first names",
                    "name_first" => "We don't like too short last names",]]));
            $validation->add('email', new PresenceOf(['message' => 'email is required']));
            $validation->add('email', new Email(['message' => 'The e-mail is not valid',]));
            $validation->add('mobile', new PresenceOf(['message' => 'mobile number is required']));
            $validation->add("mobile", new DigitValidator(["message" => "mobile number field must be numeric",]));
            $validation->add('mobile', new StringLength(["max" => 10, "min" => 10,
                "messageMaximum" => "The Mobile Number must be 10 digits long", "messageMinimum" => "The Mobile Number must be 10 digits long",]));
            $validation->add('occupation', new PresenceOf(['message' => 'occupation is required']));
            $validation->add('company_name', new PresenceOf(['message' => 'company nameis required']));

            $messages = $validation->validate($input_data->mother_info);
            if (count($messages)):
                foreach ($messages as $message):
                    $result[] = $message->getMessage();
                endforeach;
                return $this->response->setJsonContent($result);
            else:
                $users_mom = Users::findFirstByid($id);
                if ($users_mom):
                    $users_mom->id = $input_data->mother_id;
                    $users_mom->parent_type = 'mother';
                     $users_mom->user_type ='parent';
                    $users_mom->first_name = $input_data->mother_info->first_name;
                    $users_mom->last_name = $input_data->mother_info->last_name;
                    $users_mom->email = $input_data->mother_info->email;
                    $users_mom->mobile = $input_data->mother_info->mobile;
                    $users_mom->occupation = $input_data->mother_info->occupation;
                    $users_mom->company_name = $input_data->mother_info->company_name;

                    $users_mom->created_by = $input_data->mother_id;
                    $users_mom->modified_at = date('Y-m-d H:i:s');
                      $users_mom->country_of_residence = $input_data->mother_info->country_id;
                      $users_mom->country_of_citizenship =  $input_data->mother_info->citizen_id;
                    $users_mom->save();
                endif;
                $id = isset($input_data->father_id) ? $input_data->father_id : '';
                if (empty($id)):
                    return $this->response->setJsonContent(['status' => 'Error', 'message' => 'Id is null']);
                else:
                    $validation = new Validation();


                    $validation->add('first_name', new PresenceOf(['message' => 'first name is required']));
                    $validation->add('last_name', new PresenceOf(['message' => 'last name is required']));
                    $validation->add(["first_name", "last_name",], new AlphaValidator(["message" => ["first_name" => "First name must contain only  letters", "last_name " => "Last name must contain only letters",],]));
                    $validation->add(["first_name", "last_name",], new StringLength(["max" => ["first_name" => 20, "last_name" => 30,], "min" => [
                            "first_name" => 4, "last_name" => 2,],
                        "messageMaximum" => ["first_name" => "We don't like really long firstnames", "last_name" => "We don't like really long last names",], "messageMinimum" => ["name_last" => "We don't like too short first names",
                            "name_first" => "We don't like too short last names",]]));
                    $validation->add('email', new PresenceOf(['message' => 'email is required']));
                    $validation->add('email', new Email(['message' => 'The e-mail is not valid',]));
                    $validation->add('mobile', new PresenceOf(['message' => 'mobile number is required']));
                    $validation->add("mobile", new DigitValidator(["message" => "mobile number field must be numeric",]));
                    $validation->add('mobile', new StringLength(["max" => 10, "min" => 10,
                        "messageMaximum" => "The Mobile Number must be 10 digits long", "messageMinimum" => "The Mobile Number must be 10 digits long",]));
                    $validation->add('occupation', new PresenceOf(['message' => 'occupation is required']));
                    $validation->add('company_name', new PresenceOf(['message' => 'company nameis required']));

                    $messages = $validation->validate($input_data->father_info);
                    if (count($messages)):
                        foreach ($messages as $message):
                            $result[] = $message->getMessage();
                        endforeach;
                        return $this->response->setJsonContent($result);
                    else:
                        $users = Users::findFirstByid($id);
                        if ($users):
                            $users->id = $input_data->father_id;
                            $users->parent_type = 'father';
                            $users->user_type ='parent';
                            $users->first_name = $input_data->father_info->first_name;
                            $users->last_name = $input_data->father_info->last_name;
                            $users->email = $input_data->father_info->email;
                            $users->mobile = $input_data->father_info->mobile;
                            $users->occupation = $input_data->father_info->occupation;
                            $users->company_name = $input_data->father_info->company_name;

                            $users->created_by = $input_data->father_id;
                            $users->modified_at = date('Y-m-d H:i:s');
                          $users->country_of_residence = $input_data->father_info->country_id;
                             $users->country_of_citizenship =  $input_data->father_info->citizen_id;
                            if ($users->save()):
                                return $this->response->setJsonContent(['status' => true, 'message' => 'successfully']);
                            else:
                                return $this->response->setJsonContent(['status' => false, 'message' => 'Failed']);
                            endif;
                        else:
                            return $this->response->setJsonContent(['status' => false, 'message' => 'Invalid id']);
                        endif;
                    endif;
                endif;
            endif;
        endif;
    }

    /**
     * This function using delete kids caregiver information
     */
    public function delete() {

        $input_data = $this->request->getJsonRawBody();
        $id = isset($input_data->mother_id) ? $input_data->mother_id : '';
        if (empty($id)):
            return $this->response->setJsonContent(['status' => false, 'message' => 'Id is null']);
        else:
            $users_mom = Users::findFirstByid($id);
            if ($users_mom):
                $users_mom->delete();
                $id = isset($input_data->father_id) ? $input_data->father_id : '';
                if (empty($id)):
                    return $this->response->setJsonContent(['status' => false, 'message' => 'Id is null']);
                else:
                    $users = Users::findFirstByid($id);
                    if ($users):


                        if ($users->delete()):
                            return $this->response->setJsonContent(['status' => true, 'Message' => 'Record has been deleted successfully ']);
                        else:
                            return $this->response->setJsonContent(['status' => false, 'Message' => 'Data could not be deleted']);
                        endif;
                    else:
                        return $this->response->setJsonContent(['status' => false, 'Message' => 'ID doesn\'t']);
                    endif;
                endif;
            endif;
        endif;
    }

}
