<?php
use Phalcon\Mvc\Micro;
use Phalcon\Validation;
use Phalcon\Validation\Validator\PresenceOf;
use Phalcon\Validation\Validator\Email;
use Phalcon\Validation\Validator\Digit as DigitValidator;
use Phalcon\Validation\Validator\StringLength as StringLength;
use Phalcon\Validation\Validator\Alpha as AlphaValidator;
class UsersController extends \Phalcon\Mvc\Controller {
    public function index() {

    }
    /**
     * Fetch all Record from database :-
     */
    public function viewall() {
        $parentsprofile_view = Users::find();
        if ($parentsprofile_view):
            
	    return $this->response->setJsonContent ([ 
					'status' => true,
					'data' =>$parentsprofile_view
			]);
        else:
            return $this->response->setJsonContent(['status' => false, 'Message' => 'Failed']);
        endif;
    }

    /*
     * Fetch Record from database based on ID :-
     */

    public function getmyaccountinfo() {
		$headers = $this->request->getHeaders ();
		if (empty ( $headers ['Token'] )) {
			return $this->response->setJsonContent ( [
					"status" => false,
					"message" => "Please give the token"
			] );
		}
		$baseurl = $this->config->baseurl;
		$token_check = $this->tokenvalidate->tokencheck ( $headers ['Token'], $baseurl );
		if ($token_check->status != 1) {
			return $this->response->setJsonContent ( [ 
					"status" => false,
					"message" => "Invalid User" 
			] );
		}
		$user_info = $this->tokenvalidate->getuserinfo ( $headers ['Token'], $baseurl );
		$input_data = $this->request->getJsonRawBody ();
		$id = isset ( $user_info->user_info->id ) ? $user_info->user_info->id : '';
		if (empty ( $id )) {
			return $this->response->setJsonContent ( [ 
					'status' => false,
					'message' => 'Id is null'
			] );
		}
			$users = Users::findFirstByid ( $id );
			if ($users) :
			$userinfo [$users->parent_type] = $users;
			$map = ParentsMappingProfiles::findFirstByprimary_parents_id ( $id );
			if (! empty ( $map->secondary_parent_id )) {
				$secuser = Users::findFirstByid ( $map->secondary_parent_id );
				$userinfo [$secuser->parent_type] = $secuser;
			}else{
			$secusers['first_name']='';
			$secusers['last_name']='';
			$secusers['email']='';
			$secusers['mobile']='';
			$secusers['occupation']='';
			$secusers['company_name']='';
			if($users->parent_type == 'father'){
				$secusers['parent_type']='mother';
				$userinfo ['mother'] = $secusers;
			}else{
				$secusers['parent_type']='father';
				$userinfo ['father'] = $secusers;
			}
			}
			
			return $this->response->setJsonContent ([ 
					'status' => true,
					'data' => $userinfo
			]);
			
		 
			 else :
				return $this->response->setJsonContent ( [ 
						'status' => false,
						'message' => 'You have not entered any information' 
				] );
			endif;
	}

    /**
     * This function using to create NidaraParentsProfile information
     */
    public function save() {
		$headers = $this->request->getHeaders ();
		if (empty ( $headers ['Token'] )) {
			return $this->response->setJsonContent ( [
					"status" => false,
					"message" => "Please give the token"
			] );
		}
		$baseurl = $this->config->baseurl;
		$token_check = $this->tokenvalidate->tokencheck ( $headers ['Token'], $baseurl );
		if ($token_check->status != 1) {
			return $this->response->setJsonContent ( [
					"status" => false,
					"message" => "Invalid User" 
			] );
		}
		$input_data = $this->request->getJsonRawBody ();
		if (empty ( $input_data )) {
			return $this->response->setJsonContent ( [ 
					"status" => false,
					"message" => "Please give the input datas" 
			] );
		}
		/**
		 * This object using valitaion
		 */
		if (! empty ( $input_data->father )) {
			$validation = new Validation ();
			$validation->add ( 'first_name', new PresenceOf ( [ 
					'message' => 'first name is required' 
			] ) );
			$validation->add ( 'last_name', new PresenceOf ( [ 
					'message' => 'last name is required' 
			] ) );
			$validation->add ( [ 
					"first_name",
					"last_name" 
			], new AlphaValidator ( [ 
					"message" => [ 
							"first_name" => "First name must contain only  letters",
							"last_name " => "Last name must contain only letters" 
					] 
			] ) );
			$validation->add ( [ 
					"first_name",
					"last_name" 
			], new StringLength ( [ 
					"max" => [ 
							"first_name" => 20,
							"last_name" => 30 
					],
					"min" => [ 
							"first_name" => 4,
							"last_name" => 2 
					],
					"messageMaximum" => [ 
							"first_name" => "We don't like really long firstnames",
							"last_name" => "We don't like really long last names" 
					],
					"messageMinimum" => [ 
							"name_last" => "We don't like too short first names",
							"name_first" => "We don't like too short last names" 
					] 
			] ) );
			$validation->add ( 'email', new PresenceOf ( [ 
					'message' => 'email is required' 
			] ) );
			$validation->add ( 'email', new Email ( [ 
					'message' => 'The e-mail is not valid' 
			] ) );
			$validation->add ( 'mobile', new PresenceOf ( [ 
					'message' => 'mobile number is required' 
			] ) );
			$validation->add ( "mobile", new DigitValidator ( [ 
					"message" => "mobile number field must be numeric" 
			] ) );
			$validation->add ( 'mobile', new StringLength ( [ 
					"max" => 10,
					"min" => 2,
					"messageMaximum" => "The Mobile Number must be 10 digits long",
					"messageMinimum" => "The Mobile Number must be 10 digits long" 
			] ) );
			$validation->add ( 'occupation', new PresenceOf ( [ 
					'message' => 'occupation is required' 
			] ) );
			$validation->add ( 'company_name', new PresenceOf ( [ 
					'message' => 'company name is required']));
        	$messages = $validation->validate ( $input_data->father );
		if (count ( $messages )) {
				foreach ( $messages as $message ) {
					$result [] = $message->getMessage ();
				}
				return $this->response->setJsonContent ([ 
					'status' => false,
					'message' =>$result
			]);
			}
		}
                if (! empty ( $input_data->mother )) {
			$validationmother = new Validation ();
			$validationmother->add ( 'first_name', new PresenceOf ( [ 
					'message' => 'first name is required' 
			] ) );
			$validationmother->add ( 'last_name', new PresenceOf ( [ 
					'message' => 'last name is required' 
			] ) );
			$validationmother->add ( [ 
					"first_name",
					"last_name" 
			], new AlphaValidator ( [ 
					"message" => [ 
							"first_name" => "First name must contain only  letters",
							"last_name " => "Last name must contain only letters" 
					] 
			] ) );
			$validationmother->add ( [ 
					"first_name",
					"last_name" 
			], new StringLength ( [ 
					"max" => [ 
							"first_name" => 20,
							"last_name" => 30 
					],
					"min" => [ 
							"first_name" => 4,
							"last_name" => 2 
					],
					"messageMaximum" => [ 
							"first_name" => "We don't like really long firstnames",
							"last_name" => "We don't like really long last names" 
					],
					"messageMinimum" => [ 
							"name_last" => "We don't like too short first names",
							"name_first" => "We don't like too short last names" 
					] 
			] ) );
			$validationmother->add ( 'email', new PresenceOf ( [ 
					'message' => 'email is required' 
			] ) );
			$validationmother->add ( 'email', new Email ( [ 
					'message' => 'The e-mail is not valid' 
			] ) );
			$validationmother->add ( 'mobile', new PresenceOf ( [ 
					'message' => 'mobile number is required' 
			] ) );
			$validationmother->add ( "mobile", new DigitValidator ( [ 
					"message" => "mobile number field must be numeric" 
			] ) );
			$validationmother->add ( 'mobile', new StringLength ( [ 
					"max" => 10,
					"min" => 10,
					"messageMaximum" => "The Mobile Number must be 10 digits long",
					"messageMinimum" => "The Mobile Number must be 10 digits long" 
			] ) );
			$validationmother->add ( 'occupation', new PresenceOf ( [ 
					'message' => 'occupation is required' 
			] ) );
			$validationmother->add ( 'company_name', new PresenceOf ( [ 
					'message' => 'company name is required']));
        	$messagesmother = $validationmother->validate ( $input_data->mother );
		if (count ( $messagesmother )) {
				foreach ( $messagesmother as $messagemother ) {
					$resultmother [] = $messagemother->getMessage ();
				}
				return $this->response->setJsonContent ([ 
					'status' => false,
					'message' =>$resultmother
			]);
			}
		}
		$baseurl = $this->config->baseurl;
		$token_validate = $this->tokenvalidate->getuserinfo ( $headers ['Token'], $baseurl );
		if(empty($token_validate)){
			return $this->response->setJsonContent ( [
					'status' => false,
					'message' => 'Invalid User'
			] );
		}
		$username = $token_validate->user_info->email;
		$user = Users::findFirstByemail ( $username );
		foreach ( $input_data as $key => $userinfo ) {
			if ($userinfo->id) {
				$users = Users::findFirstByid ( $userinfo->id );
				if(empty($users)){
					return $this->response->setJsonContent ( [
						'status' => false,
						'message' => 'Please give the valid user id'
					] );
				}
			} else {
				$users = new Users ();
				$users->id = $this->parentsidgen->getNewId ( "users" );
			}
			$users->parent_type = $key;
			$users->user_type = 'parent';
			$users->first_name = $userinfo->first_name;
			$users->last_name = $userinfo->last_name;
			$users->email = $userinfo->email;
			$users->mobile = $userinfo->mobile;
			$users->occupation = $userinfo->occupation;
			$users->company_name = $userinfo->company_name;
			$users->created_at = date ( 'Y-m-d H:i:s' );
			$users->created_by = $user->id;
			$users->modified_at = date ( 'Y-m-d H:i:s' );
			$users->status = 1;
			$users->save ();
			if ($user->id != $users->id) {
				$parents_map = ParentsMappingProfiles::findFirstByprimary_parents_id ( $user->id );
				if ($parents_map) {
					$parents_map->secondary_parent_id = $users->id;
					$parents_map->secondary_parent_type = $key;
					$parents_map->save ();
				}
			}
		}
		return $this->response->setJsonContent ( [ 
				'status' => true,
				'message' => 'Account information updated successfully' 
		] );
	}

    /**
     * This function using to NidaraParentsProfile information edit
     */
    public function update() {

        $input_data = $this->request->getJsonRawBody();
        $id = isset($input_data->id) ? $input_data->id : '';
        if (empty($id)):
            return $this->response->setJsonContent(['status' => false, 'message' => 'Id is null']);
        else:
            $validation = new Validation();
            $validation->add('parent_type', new PresenceOf(['message' => 'Parent type is required']));
            $validation->add('first_name', new PresenceOf(['message' => 'First Name is required']));
            $validation->add('last_name', new PresenceOf(['message' => 'Last Name is required']));
            $validation->add('email', new PresenceOf(['message' => 'Email is required']));
            $validation->add('mobile', new PresenceOf(['message' => 'Mobile Number is required']));
            $validation->add('occupation', new PresenceOf(['message' => 'Occupation is required']));
            $validation->add('company_name', new PresenceOf(['message' => 'Company Name is required']));
            $messages = $validation->validate($input_data);
            if (count($messages)):
                foreach ($messages as $message):
                    $result[] = $message->getMessage();
                endforeach;
		return $this->response->setJsonContent ([ 
					'status' => false,
					'message' =>$result
			]);
                //return $this->response->setJsonContent($result);
            else:
                $parentsprofile_update = Users::findFirstByid($id);
                if ($parentsprofile_update):
                    $parentsprofile_update->id = $input_data->id;
                    $parentsprofile_update->parent_type = $input_data->parent_type;
                    $parentsprofile_update->first_name = $input_data->first_name;
                    $parentsprofile_update->last_name = $input_data->last_name;
                    $parentsprofile_update->email = $input_data->email;
                    $parentsprofile_update->mobile = $input_data->mobile;
                    $parentsprofile_update->occupation = $input_data->occupation;
                    $parentsprofile_update->company_name = $input_data->company_name;
                    $parentsprofile_update->created_by = $id;
                    $parentsprofile_update->modified_at =date('Y-m-d H:i:s');
                    if ($parentsprofile_update->save()):
                        return $this->response->setJsonContent(['status' => true, 'message' => 'succefully']);
                    else:
                        return $this->response->setJsonContent(['status' => false, 'message' => 'Failed']);
                    endif;
                else:
                    return $this->response->setJsonContent(['status' => false, 'message' => 'Invalid id']);
                endif;
            endif;
        endif;
    }

    /**
     * This function using delete kids caregiver information
     */
    public function delete() {

        $input_data = $this->request->getJsonRawBody();
        $id = isset($input_data->id) ? $input_data->id : '';
        if (empty($id)):
            return $this->response->setJsonContent(['status' => false, 'message' => 'Id is null']);
        else:
            $parentsprofile_delete = Users::findFirstByid($id);
            if ($parentsprofile_delete):
                if ($parentsprofile_delete->delete()):
                    return $this->response->setJsonContent(['status' => true, 'Message' => 'Record has been deleted succefully ']);
                else:
                    return $this->response->setJsonContent(['status' => false, 'Message' => 'Data could not be deleted']);
                endif;
            else:
                return $this->response->setJsonContent(['status' => false, 'Message' => 'ID doesn\'t']);
            endif;
        endif;
    }
	
	/**
	 * Country updation by kid id
	 */
	public function countryupdatebyuserid() {
		try {
			$headers = $this->request->getHeaders ();
			if (empty ( $headers ['Token'] )) {
				return $this->response->setJsonContent ( [
						"status" => false,
						"message" => "Please give the token"
				] );
			}
			$baseurl = $this->config->baseurl;
			$token_check = $this->tokenvalidate->tokencheck ( $headers ['Token'], $baseurl );
			if ($token_check->status != 1) {
				return $this->response->setJsonContent ( [
						"status" => false,
						"message" => "Invalid User"
				] );
			}
			$user_info=$this->tokenvalidate->getuserinfo ( $headers ['Token'], $baseurl );
			$input_data = $this->request->getJsonRawBody ();
			$id = isset ( $user_info->user_info->id ) ? $user_info->user_info->id : '';
			if (empty ( $id )) {
				return $this->response->setJsonContent ( [ 
						'status' => false,
						'message' => 'Id is null' 
				] );
			}
			$validation = new Validation ();
			$validation->add ( 'country_of_residence', new PresenceOf ( [ 
					'message' => 'Country of residence is required' 
			] ) );
			$validation->add ( 'country_of_citizenship', new PresenceOf ( [ 
					'message' => 'Country of citizen is required' 
			] ) );
			$messages = $validation->validate ( $input_data );
			if (count ( $messages )) {
				foreach ( $messages as $message ) {
					$result [] = $message->getMessage ();
				}
				return $this->response->setJsonContent ([ 
					'status' => false,
					'message' =>$result
			]);
			}
			
			$users = Users::findFirstByid ( $id );
			if ($users) :
				$users->country_of_residence = $input_data->country_of_residence;
				$users->country_of_citizenship = $input_data->country_of_citizenship;
				if ($users->save ()) :
					return $this->response->setJsonContent ( [ 
							'status' => true,
							'message' => 'Country updated successfully' 
					] );
				 else :
					return $this->response->setJsonContent ( [ 
							'status' => false,
							'message' => 'Failed' 
					] );
				endif;
			 
			 else :
				return $this->response->setJsonContent ([ 
						'status' => false,
						'message' => 'Invalid id' 
				]);
			endif;
			} catch ( Exception $e ) {
				return $this->response->setJsonContent ( [
						'status' => false,
						'message' => 'Cannot update country details'
				] );
			}
	}
	public function getcountryinfo(){
		$headers = $this->request->getHeaders ();
		if (empty ( $headers ['Token'] )) {
			return $this->response->setJsonContent ( [
					"status" => false,
					"message" => "Please give the token"
			] );
		}
		$baseurl = $this->config->baseurl;
		$token_check = $this->tokenvalidate->tokencheck ( $headers ['Token'], $baseurl );
		if ($token_check->status != 1) {
			return $this->response->setJsonContent ( [
					"status" => false,
					"message" => "Invalid User"
			] );
		}
		$user_info=$this->tokenvalidate->getuserinfo ( $headers['Token'], $baseurl );
		$input_data = $this->request->getJsonRawBody ();
		$id = isset ( $user_info->user_info->id ) ? $user_info->user_info->id : '';
		if (empty ( $id )) {
			return $this->response->setJsonContent ( [
					'status' => false,
					'message' => 'Id is null'
			] );
		}
		$user = Users::findFirstByid ( $id );
		if (! empty ( $user )) {
			$country ['country_of_residence'] = $user->country_of_residence;
			$country ['country_of_citizenship'] = $user->country_of_citizenship;
			$country ['user_id'] = $user->id;
			
		}
		return $this->response->setJsonContent ([ 
					'status' => true,
					'data' =>$country
			]);
		
	}
}
